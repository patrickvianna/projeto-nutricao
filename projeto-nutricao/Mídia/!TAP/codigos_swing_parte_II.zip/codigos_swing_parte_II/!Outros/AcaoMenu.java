import javax.swing.*;
import javax.swing.filechooser.*;
import java.awt.event.*;
import java.io.File;

public class AcaoMenu extends JFrame {
   String extensao = "txt";

   public AcaoMenu() {
      super("Menu");

      setBounds(100,100,300,300);
      bar = new JMenuBar();
      arquivo = new JMenu("Arquivo");
      miabrir = new JMenuItem("Abrir");
      miabrir.setEnabled(false);
      misalvar = new JMenuItem("Salvar");
      mipodeabrir = new JCheckBoxMenuItem("Pode abrir");
      miextensaodoc = new JRadioButtonMenuItem("Extensao .doc");
      miextensaotxt = new JRadioButtonMenuItem("Extensao .txt");
      ButtonGroup bg = new ButtonGroup();
      bg.add(miextensaodoc);
      bg.add(miextensaotxt);
      miextensaotxt.setSelected(true);
      misair = new JMenuItem("Sair");

      arquivo.add(miabrir);
      arquivo.add(misalvar);
      arquivo.addSeparator();
      arquivo.add(mipodeabrir);
      arquivo.addSeparator();
      arquivo.add(miextensaodoc);
      arquivo.add(miextensaotxt);
      arquivo.addSeparator();
      arquivo.add(misair);

      sobre = new JMenu("Sobre");
      bar.add(arquivo);
      bar.add(sobre);

      setJMenuBar(bar);

      arquivo.setMnemonic(KeyEvent.VK_A);
      sobre.setMnemonic(KeyEvent.VK_S);

      miabrir.setMnemonic(KeyEvent.VK_A);
      misalvar.setMnemonic(KeyEvent.VK_S);
      mipodeabrir.setMnemonic(KeyEvent.VK_P);
      miextensaodoc.setMnemonic(KeyEvent.VK_D);
      miextensaotxt.setMnemonic(KeyEvent.VK_T);

      eventos = new JTextArea();
      getContentPane().add(new JScrollPane(eventos));
   
      miabrir.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent ae)
         {
            JFileChooser chooser = new JFileChooser();
            Filtro filtro = new Filtro(extensao);
            chooser.setFileFilter(filtro);
            int returnVal = chooser.showOpenDialog(AcaoMenu.this);
            if(returnVal == JFileChooser.APPROVE_OPTION)
               eventos.append("Voce escolheu abrir: " + chooser.getSelectedFile().getName()+"\n");
         }
      } );
      misalvar.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent ae)
         {
            JFileChooser chooser = new JFileChooser();
            Filtro filtro = new Filtro(extensao);
            chooser.setFileFilter(filtro);
            int returnVal = chooser.showSaveDialog(AcaoMenu.this);
            if(returnVal == JFileChooser.APPROVE_OPTION)
               eventos.append("Voce escolheu salvar: " + chooser.getSelectedFile().getName()+"\n");
         }
      } );
      misair.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent ae)
         {
            System.exit(0);
         }
      } );
      mipodeabrir.addItemListener(new ItemListener()
      {
         public void itemStateChanged(ItemEvent e)
         {
            clickedPodeAbrir();
         }
      } );
      miextensaodoc.addItemListener(new ItemListener()
      {
         public void itemStateChanged(ItemEvent e)
         {
            extensao = "doc";
         }
      } );
      miextensaotxt.addItemListener(new ItemListener()
      {
         public void itemStateChanged(ItemEvent e)
         {
            extensao = "txt";
         }
      } );
   }

   protected void clickedPodeAbrir() {
      miabrir.setEnabled(mipodeabrir.getState());
   }

   public static void main(String args[]) {
        AcaoMenu app = new AcaoMenu();
        app.setVisible(true);

  		app.addWindowListener(new WindowAdapter(){
		public void windowClosing(WindowEvent e){
			System.exit(0);
		}
	});
  }
   

   JTextArea eventos;
   JMenuBar bar;
   JMenu arquivo;
   JMenuItem miabrir;
   JMenuItem misalvar;
   JCheckBoxMenuItem mipodeabrir;
   JRadioButtonMenuItem miextensaodoc;
   JRadioButtonMenuItem miextensaotxt;
   JMenuItem misair;
   JMenu sobre;

   class Filtro extends FileFilter {
      String extensao;

      public Filtro(String extensao) {
         super();
         this.extensao = extensao;
      }

      public boolean accept(File f) {
         if (f.isDirectory())
            return true;
         if(f.getName().endsWith("."+extensao)) return true;
         return false;
      }
    
      public String getDescription()
      {
         return "Documento : *."+extensao;
      }
   }
}

