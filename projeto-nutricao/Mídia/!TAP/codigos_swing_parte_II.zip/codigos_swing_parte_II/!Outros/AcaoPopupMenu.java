import javax.swing.*;
import javax.swing.filechooser.*;
import java.awt.event.*;
import java.awt.*;
import java.io.File;

public class AcaoPopupMenu extends JFrame {
   String extensao = "txt";

   public AcaoPopupMenu() {
      super("Popup Menu");

      popup = new JPopupMenu();

      setBounds(100,100,300,300);
      arquivo = new JMenu("Arquivo");
      miabrir = new JMenuItem("Abrir");
      miabrir.setEnabled(false);
      misalvar = new JMenuItem("Salvar");
      mipodeabrir = new JCheckBoxMenuItem("Pode abrir");
      miextensaodoc = new JRadioButtonMenuItem("Extensao .doc");
      miextensaotxt = new JRadioButtonMenuItem("Extensao .txt");
      ButtonGroup bg = new ButtonGroup();
      bg.add(miextensaodoc);
      bg.add(miextensaotxt);
      miextensaotxt.setSelected(true);
      misair = new JMenuItem("Sair");

      arquivo.add(miabrir);
      arquivo.add(misalvar);
      arquivo.addSeparator();
      arquivo.add(mipodeabrir);
      arquivo.addSeparator();
      arquivo.add(miextensaodoc);
      arquivo.add(miextensaotxt);
      arquivo.addSeparator();
      arquivo.add(misair);

      sobre = new JMenu("Sobre");
      popup.add(arquivo);
      popup.add(sobre);

      arquivo.setMnemonic(KeyEvent.VK_A);
      sobre.setMnemonic(KeyEvent.VK_S);

      miabrir.setMnemonic(KeyEvent.VK_A);
      misalvar.setMnemonic(KeyEvent.VK_S);
      mipodeabrir.setMnemonic(KeyEvent.VK_P);
      miextensaodoc.setMnemonic(KeyEvent.VK_D);
      miextensaotxt.setMnemonic(KeyEvent.VK_T);

      eventos = new JTextArea();
      getContentPane().add(new JScrollPane(eventos));

      JButton botaomenu = new JButton("Clique aqui para o menu");
      getContentPane().add(botaomenu,BorderLayout.EAST);

      botaomenu.addMouseListener(new MouseAdapter()
      {
         public void mouseReleased(MouseEvent e)
         {
            clickedMenu(e.getComponent(),e.getX(),e.getY());
         }
      } );
   
      miabrir.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent ae)
         {
            JFileChooser chooser = new JFileChooser();
            Filtro filtro = new Filtro(extensao);
            chooser.setFileFilter(filtro);
            int returnVal = chooser.showOpenDialog(AcaoPopupMenu.this);
            if(returnVal == JFileChooser.APPROVE_OPTION)
               eventos.append("Voce escolheu abrir: " + chooser.getSelectedFile().getName()+"\n");
         }
      } );
      misalvar.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent ae)
         {
            JFileChooser chooser = new JFileChooser();
            Filtro filtro = new Filtro(extensao);
            chooser.setFileFilter(filtro);
            int returnVal = chooser.showSaveDialog(AcaoPopupMenu.this);
            if(returnVal == JFileChooser.APPROVE_OPTION)
               eventos.append("Voce escolheu salvar: " + chooser.getSelectedFile().getName()+"\n");
         }
      } );
      misair.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent ae)
         {
            System.exit(0);
         }
      } );
      mipodeabrir.addItemListener(new ItemListener()
      {
         public void itemStateChanged(ItemEvent e)
         {
            clickedPodeAbrir();
         }
      } );
      miextensaodoc.addItemListener(new ItemListener()
      {
         public void itemStateChanged(ItemEvent e)
         {
            extensao = "doc";
         }
      } );
      miextensaotxt.addItemListener(new ItemListener()
      {
         public void itemStateChanged(ItemEvent e)
         {
            extensao = "txt";
         }
      } );
   }

   protected void clickedPodeAbrir() {
      miabrir.setEnabled(mipodeabrir.getState());
   }

   protected void clickedMenu(Component c,int x, int y) {

      popup.show(c,x,y);
   }

   JTextArea eventos;
   JPopupMenu popup;
   JMenu arquivo;
   JMenuItem miabrir;
   JMenuItem misalvar;
   JCheckBoxMenuItem mipodeabrir;
   JRadioButtonMenuItem miextensaodoc;
   JRadioButtonMenuItem miextensaotxt;
   JMenuItem misair;
   JMenu sobre;

   JButton botaomenu;

   class Filtro extends FileFilter {
      String extensao;

      public Filtro(String extensao) {
         super();
         this.extensao = extensao;
      }

      public boolean accept(File f) {
         if (f.isDirectory())
            return true;
         if(f.getName().endsWith("."+extensao)) return true;
         return false;
      }
    
      public String getDescription() {
         return "Documento : *."+extensao;
      }
   }

   public static void main(String args[]) {
     AcaoPopupMenu app = new AcaoPopupMenu();
     app.setVisible(true);
      
	 // Evento associado a fechar a janela
	 app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);      
   }
}

