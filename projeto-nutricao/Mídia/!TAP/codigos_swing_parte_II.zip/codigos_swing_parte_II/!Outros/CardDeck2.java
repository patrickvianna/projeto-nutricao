import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CardDeck2 extends JFrame implements ActionListener {
   private CardLayout cardManager;
   private JPanel deck;
   private JButton controls[];
   private String names[] = { "First card", "Next card",
                              "Previous card", "Last card" };

   public CardDeck2() {
      super( "CardLayout " );

      Container c = getContentPane();

      // cria um JPanel com CardLayout
      deck = new JPanel();
      cardManager = new CardLayout(); 
      deck.setLayout( cardManager );  

      // setup card1 e adiciona-o ao deck JPanel (deck = maço de carta)
      JLabel label1 = new JLabel( "card one", SwingConstants.CENTER );
      JPanel card1 = new JPanel();
      card1.add( label1 ); 
      deck.add( card1, label1.getText() ); // adiciona card ao deck
      
      // setup card2 e adiciona-o ao deck JPanel
      JLabel label2 = new JLabel( "card two", SwingConstants.CENTER );
      JPanel card2 = new JPanel();
      card2.setBackground( Color.yellow );
      card2.add( label2 );
      deck.add( card2, label2.getText() ); // adiciona card ao deck

      // setup card3 e adiciona-o ao deck JPanel
      JLabel label3 = new JLabel( "card three" );
      JPanel card3 = new JPanel();
      card3.setLayout( new BorderLayout() );  
      card3.add( new JButton( "North" ), BorderLayout.NORTH );
      card3.add( new JButton( "West" ), BorderLayout.WEST );
      card3.add( new JButton( "East" ), BorderLayout.EAST );
      card3.add( new JButton( "South" ), BorderLayout.SOUTH );
      card3.add( label3, BorderLayout.CENTER );
      deck.add( card3, label3.getText() ); // adiciona card ao deck

      // cria os butões e o layout que irá controlar o deck
      JPanel buttons = new JPanel();
      buttons.setLayout( new GridLayout( 2, 2 ) );
      controls = new JButton[ names.length ];

      for ( int i = 0; i < controls.length; i++ ) {
         controls[ i ] = new JButton( names[ i ] );
         controls[ i ].addActionListener( this );
         buttons.add( controls[ i ] );
      }

      c.add( buttons, BorderLayout.WEST );
      c.add( deck, BorderLayout.EAST );

      setSize( 450, 200 );
      show();
   }

   public void actionPerformed( ActionEvent e )
   {
      if ( e.getSource() == controls[ 0 ] )    
         cardManager.first( deck ); // mostra primeiro card
      else if ( e.getSource() == controls[ 1 ] )    
         cardManager.next( deck );  // mostra próximo card
      else if ( e.getSource() == controls[ 2 ] )
         cardManager.previous( deck );  // mostra card anterior
      else if ( e.getSource() == controls[ 3 ] )
         cardManager.last( deck );  // mostra último card            
   }

   public static void main( String args[] ) {
      CardDeck2 cardDeckDemo = new CardDeck2();

      cardDeckDemo.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );
   }
}

