import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DemoEventosMouse2 extends JFrame{
	
	private JLabel barraStatus;
	
	public DemoEventosMouse2(){
		setTitle("Usando Eventos Mouse");
		
		barraStatus = new JLabel();
		getContentPane().add(barraStatus,BorderLayout.SOUTH);
		
		MouseHandler handler = new MouseHandler();
		addMouseListener(handler);
		
		setSize(275,100);
		show();
	}
	
	public static void main(String args[]){
		DemoEventosMouse2 app = new DemoEventosMouse2();
		
		app.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
	}

	private class MouseHandler extends MouseAdapter{
			
			public void mouseClicked(MouseEvent e){
				barraStatus.setText("Mouse foi pressionado");
			}
			
			public void mouseEntered(MouseEvent e){
				barraStatus.setText("Mouse esta dentro da janela");
			}
			
			public void mouseExited(MouseEvent e){
				barraStatus.setText("Mouse esta fora da janela");
			}
	}
}