import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DemoEventosMouseMotion1 extends JFrame {
   private JButton jButton1, jButton2;

   public DemoEventosMouseMotion1() {
      super( "Usando JButton" );

      Container c = getContentPane();
      c.setLayout( new FlowLayout() );

      // cria os botões
      jButton1 = new JButton( "jButton1" );
      c.add( jButton1 );

      Icon icone1 = new ImageIcon( "computador.gif" );
      Icon icone2 = new ImageIcon( "luz.gif" );
      jButton2 = new JButton( "jButton2", icone1 );
      jButton2.setRolloverIcon(icone2 );
      c.add( jButton2 );

      // criar uma instancia de classe interna ButtonHandler
      // para usar o evento de botao handling 
      ButtonHandler handler = new ButtonHandler();
      jButton1.addActionListener( handler );
      jButton2.addActionListener( handler );
	  jButton1.addMouseMotionListener( handler );
      jButton2.addMouseMotionListener( handler );

      setSize( 275, 100 );
      show();
   }

   public static void main( String args[] ) { 
      DemoEventosMouseMotion1 app = new DemoEventosMouseMotion1();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );
   }

   // classe interna para evento de botoes handling
   private class ButtonHandler extends MouseMotionAdapter implements ActionListener{
      public void actionPerformed( ActionEvent e )
      {
         JOptionPane.showMessageDialog( null,
            "Voce pressionou: " + e.getActionCommand() );
      }
   
   	  public void mouseMoved(MouseEvent e)
   	  {
   	  	System.out.println("Mouse sobre os Botoes");
   	  }
   }
}

