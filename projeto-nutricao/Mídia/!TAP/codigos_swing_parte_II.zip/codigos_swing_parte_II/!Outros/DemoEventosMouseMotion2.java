import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DemoEventosMouseMotion2 extends JFrame 
								implements MouseListener, MouseMotionListener { 
	private JLabel statusBar;
	
	public DemoEventosMouseMotion2(){ 
		super("Demonstrating Mouse Events");
		
		statusBar = new JLabel(); 
		getContentPane().add( statusBar, BorderLayout.SOUTH );
		
		this.addMouseListener(this); 
		this.addMouseMotionListener(this);
		
		setSize(275, 100); 
		show(); 
	} 

	// Tratadores de MouseListener 
	public void mouseClicked( MouseEvent e )
	{ 
		statusBar.setText( "Clique em [" + e.getX() + ", " + e.getY() + "]" ); 
	} 
	
	public void mousePressed( MouseEvent e )
	{ 
		statusBar.setText( "Pressionado em [" + e.getX() + ", " + e.getY() + "]" ); 
	} 
	
	public void mouseReleased( MouseEvent e )
	{ 
		statusBar.setText( "Solto em [" + e.getX() + ", " + e.getY() + "]" ); 
	} 
	
	public void mouseEntered( MouseEvent e )
	{
		statusBar.setText( "Mouse dentro da janela" ); 
	} 
	
	public void mouseExited( MouseEvent e )
	{ 
		statusBar.setText( "Mouse fora da janela" );
	}	


	// Tratadores de MouseMotionListener 
	public void mouseDragged( MouseEvent e )
	{ 
		statusBar.setText( "Arrastado em [" + e.getX() + ", " + e.getY() + "]" ); 
	}
	
	public void mouseMoved( MouseEvent e )
	{
		statusBar.setText( "Movido em [" + e.getX() + ", " + e.getY() + "]" );
	}
	
	public static void main( String args[] ) { 
		  DemoEventosMouseMotion2 app = new DemoEventosMouseMotion2(); 

	      app.addWindowListener(
	         new WindowAdapter() {
	            public void windowClosing( WindowEvent e )
	            {
	               System.exit( 0 );
	            }
	         }
	      );
	}
}
