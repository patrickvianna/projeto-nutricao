import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DemoEventosTeclas1 extends JFrame {
	
	private JLabel barraStatus;
	
	public DemoEventosTeclas1(){
		setTitle("Usando Eventos Teclado");
		
		barraStatus = new JLabel();
		getContentPane().add(barraStatus,BorderLayout.SOUTH);
		
		TecladoHandler handler = new TecladoHandler();
		addKeyListener(handler);
		
		setSize(275,100);
		show();
	}
	
	public static void main(String args[]){
		DemoEventosTeclas1 app = new DemoEventosTeclas1();
		
		app.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
	}

	private class TecladoHandler extends KeyAdapter{
			
			public void keyPressed(KeyEvent e){
				barraStatus.setText("Tecla normal pressionada: "+ e.getKeyChar());
			
				if (e.isActionKey())
				barraStatus.setText("Tecla de acao pressionada ");
			}
	}
}