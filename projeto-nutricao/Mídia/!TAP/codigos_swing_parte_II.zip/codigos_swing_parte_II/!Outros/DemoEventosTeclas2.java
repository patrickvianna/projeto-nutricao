import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DemoEventosTeclas2 extends JFrame implements KeyListener { 
							
	private String line1 = "", line2 = ""; 
	private String line3 = ""; 
	private JTextArea textArea;

	public DemoEventosTeclas2() { 
		super( "Demostrando eventos de teclado" );

		textArea = new JTextArea( 10, 15 ); 
		textArea.setText("Pressione qualquer tecla..." ); 
		textArea.setEnabled( false ); 
		
		addKeyListener( this ); 
		
		getContentPane().add( textArea );
		setSize( 350, 100 ); 
		show(); 
	}

	public void keyPressed( KeyEvent e )
	{ 
		line1 = "Tecla pressionada: " + e.getKeyText( e.getKeyCode() ); 
		setLines2and3( e ); 
	}
	
	public void keyReleased( KeyEvent e )
	{ 
		line1 = "Tecla solta/liberada: " + e.getKeyText( e.getKeyCode() ); 
		setLines2and3( e ); 
	}
	
	public void keyTyped( KeyEvent e )
	{ 
		line1 = "Tecla digitada: " + e.getKeyChar(); 
		setLines2and3( e ); 
	}


	public void setLines2and3 ( KeyEvent e ){ 
		line2 = "Esta tecla eh " + (e.isActionKey() ? "" : "nao") + " uma tecla de acao";
		
		String temp = e.getKeyModifiersText(e.getModifiers());
		line3 = "Tecla Modificadora pressionada: " + (temp.equals("") ? "nenhuma" : temp);
		
		textArea.setText(line1+"\n" + line2 + "\n" + line3 +"\n"); 
	}

	public static void main( String args[] ){ 
		DemoEventosTeclas2 app = new DemoEventosTeclas2();

		app.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
	} 
} 