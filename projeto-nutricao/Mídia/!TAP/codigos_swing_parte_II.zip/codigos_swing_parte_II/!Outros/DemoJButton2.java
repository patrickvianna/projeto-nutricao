import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DemoJButton2 extends JFrame {
   private JButton jButton1, jButton2;

   public DemoJButton2()  {
      super( "Usando JButton" );

      Container c = getContentPane();
      c.setLayout( new FlowLayout() );

      // cria os botões
      jButton1 = new JButton( "jButton1" );
      c.add( jButton1 );

      Icon icone1 = new ImageIcon( "computador.gif" );
      Icon icone2 = new ImageIcon( "luz.gif" );
      jButton2 = new JButton( "jButton2", icone1 );
      jButton2.setRolloverIcon(icone2 );
      c.add( jButton2 );

      jButton2.addActionListener(new ActionListener(){
      	
		      public void actionPerformed( ActionEvent e ) {
		         JOptionPane.showMessageDialog( null,
		            "Voce pressionou: JButton2");
		      }
      	
      	});
      
      jButton1.addActionListener(new ActionListener(){
      	
		      public void actionPerformed( ActionEvent e ) {
		         JOptionPane.showMessageDialog( null,
		            "Voce pressionou: JButton1");
		      }
      	
      	});

      setSize( 275, 100 );
      show();
   }

   public static void main( String args[] ) { 
      DemoJButton2 app = new DemoJButton2();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );
   }

}

