import javax.swing.*;
import java.awt.event.*;

public class DemoJLabel2 extends JFrame {
   private JLabel label1, label2, label3, label4 ;

   public DemoJLabel2() {
      super( "Usando JLabel" );

	  JPanel pane = new JPanel();

      // Criando JLabel com argumento String no construtor
      label1 = new JLabel( "JLabel com texto" );
      label1.setToolTipText( "JLabel label1" );
	  pane.add( label1 );

      // Criando JLabel com argumento String, Icone e alinhamento no construtor
      Icon icone = new ImageIcon( "computador.gif" );
      label2 = new JLabel( "JLabel com texto e icone ", icone, SwingConstants.RIGHT);
      // Sets the vertical position of the label's text, relative to its image.
      label2.setVerticalTextPosition(SwingConstants.TOP );
      label2.setToolTipText( "JLabel label2" ); //seta Hint
	  pane.add( label2 );

      // Criando JLabel sem argumentos no construtor
      label3 = new JLabel();
      label3.setText( "JLabel com icone e texto no label" );
      label3.setIcon( icone );
      label3.setHorizontalTextPosition(SwingConstants.CENTER );
      label3.setVerticalTextPosition(SwingConstants.BOTTOM );
      label3.setToolTipText( "JLabel label3" );
      pane.add( label3 );

	   // Criando JLabel somente com icone
	  label4 = new JLabel(icone);
      label4.setToolTipText( "JLabel label4" ); //seta Hint
	  pane.add( label4 );

      this.getContentPane().add( pane );
      setSize( 600, 200 );
      show();
   }

   public static void main( String args[] ) { 

      DemoJLabel2 app = new DemoJLabel2();

  	  // Recurso de eventos
      // O objeto evento (WindowEvent) está sendo englobado pelo objeto 
      // WindowAdapter que está sendo passado para o Listerner WindowListener
      // O método windowClosing está sendo sobreescrito
      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               
               JOptionPane.showMessageDialog( null, "Voce selecionou: " + e );               
               System.exit( 0 );
            }
         }
      );

/*
	 // Evento associado a fechar a janela
	 app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
*/

   }
}

