import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class DemoJList1 extends JFrame {
   private JList jList;
   private Container c;
 
   private String nomesCores[] =
      { "Preto", "Azul", "Cinza", "Verde", "Laranja", "Rosa", "Vermelho",
        "Branco", "Amarelo" };

   private Color cores[] =
      { Color.black, Color.blue, Color.gray, Color.green, Color.orange, Color.pink, Color.red,
        Color.white, Color.yellow };

   public DemoJList1()
   {
      super( "Usando JList" );

      c = getContentPane();
      c.setLayout( new FlowLayout() );

      
      // cria uma lista com os itens do array nomesCores
      jList = new JList( nomesCores );
      // seta quantidades de linhas a serem exibidas
      jList.setVisibleRowCount( 5 );
      
      // define o JList com seleo nica
      jList.setSelectionMode(
         ListSelectionModel.SINGLE_SELECTION );

      // adiciona um JScrollPane pertencente ao JList
      // adicionando um JScrollPane (barra de rolagem) pois o
      // componente JList nao o disponibiliza
      c.add( new JScrollPane( jList ) );

      // set up event handler
      jList.addListSelectionListener(
         new ListSelectionListener() {
            public void valueChanged( ListSelectionEvent e )  
            {
               c.setBackground(
                  cores[ jList.getSelectedIndex() ] );
            }
         }
      );

      setSize( 350, 150 );
      show();
   }

   public static void main( String args[] )
   { 
      DemoJList1 app = new DemoJList1();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );
   }
}

