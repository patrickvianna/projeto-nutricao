import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DemoJList2 extends JFrame {
   private JList colorList, copyList;
   private JButton copy;

 
   private String nomesCores[] =
      { "Preto", "Azul", "Cinza", "Verde", "Laranja", "Rosa", "Vermelho",
        "Branco", "Amarelo" };


   public DemoJList2()    {
      super( "Usando multipla selecao" );

      Container c = getContentPane();
      c.setLayout( new FlowLayout() );

      colorList = new JList( nomesCores );
      colorList.setVisibleRowCount( 5 );
      //seta a altura de cada item da JList
      colorList.setFixedCellHeight( 15 );
      colorList.setSelectionMode(
         ListSelectionModel.MULTIPLE_INTERVAL_SELECTION );
      c.add( new JScrollPane( colorList ) );

      // cria o botão de cópia
      copy = new JButton( "Copia >>>" );
      copy.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
               // coloca os valores selecionados em copyList
               copyList.setListData(
                  colorList.getSelectedValues() );
            }
         }
      );
      c.add( copy );

      copyList = new JList( );
      copyList.setVisibleRowCount( 5 );
      //seta a largura da JList
      copyList.setFixedCellWidth( 100 );
      //seta a altura de cada item da JList
      copyList.setFixedCellHeight( 15 );
      copyList.setSelectionMode(
         ListSelectionModel.SINGLE_INTERVAL_SELECTION );
      c.add( new JScrollPane( copyList ) );

      setSize( 300, 120 );
      show();
   }

   public static void main( String args[] )
   { 
      DemoJList2 app = new DemoJList2();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );
   }
}

