import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DemoJRadioButton1 extends JFrame {
   private JTextField t;
   private Font fNormal, fNegrito,
                fItalico, fNegritoItalico;
   private JRadioButton normal, negrito, italico, negritoItalico;
   private ButtonGroup radioGroup;

   public DemoJRadioButton1() {
      super( "Usando RadioButton" );

      Container c = getContentPane();
      c.setLayout( new FlowLayout() );

      t = new JTextField( "Selecione e mude o estilo da fonte", 25 );
      c.add( t ); 

      // Criando os JRatioButton
      // Construtor JRatioButton(Texto, aparecer selecionado);
      normal = new JRadioButton( "Normal", true );
      c.add( normal );
      negrito = new JRadioButton( "Negrito", false);
      c.add( negrito );
      italico = new JRadioButton( "Italico", false );
      c.add( italico );
      negritoItalico = new JRadioButton( "Negrito/Italico", false );
      c.add( negritoItalico );

      // Tratando os eventos
      // Adicionando listeners utilizando handler "Tratador" eventos
      RadioButtonHandler handler = new RadioButtonHandler();
      normal.addItemListener( handler );
      negrito.addItemListener( handler );
      italico.addItemListener( handler );
      negritoItalico.addItemListener( handler );

      // cria uma relação lógica entre os JRadioButtons
      radioGroup = new ButtonGroup();
      radioGroup.add( normal );
      radioGroup.add( negrito );
      radioGroup.add( italico );
      radioGroup.add( negritoItalico );

      fNormal = new Font( "TimesRoman", Font.PLAIN, 14 );
      fNegrito = new Font( "TimesRoman", Font.BOLD, 14 );
      fItalico = new Font( "TimesRoman", Font.ITALIC, 14 );
      fNegritoItalico =
         new Font( "TimesRoman", Font.BOLD + Font.ITALIC, 14 );
      t.setFont( fNormal );

      setSize( 350, 100 );
      show();
   }

   public static void main( String args[] )
   {
      DemoJRadioButton1 app = new DemoJRadioButton1();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );
   }

   private class RadioButtonHandler implements ItemListener {
      public void itemStateChanged( ItemEvent e )
      {
         if ( e.getSource() == normal ) 
            t.setFont( fNormal );
         else if ( e.getSource() == negrito ) 
            t.setFont( fNegrito );
         else if ( e.getSource() == italico ) 
            t.setFont( fItalico );
         else if ( e.getSource() == negritoItalico ) 
            t.setFont( fNegritoItalico );

         t.repaint();
      }
   }
}

