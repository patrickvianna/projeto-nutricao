import java.awt.*;
import java.awt.event.*; 
import javax.swing.*;

public class DemoJtfJpf2 extends JFrame {
   private JTextField text1, text2, text3;
   private JPasswordField password;

   public DemoJtfJpf2() {
      super( "Usando JTextField e JPasswordField" );

      Container c = getContentPane();
      c.setLayout( new FlowLayout() );

      // Construtor textfield com tamanho padrao
      text1 = new JTextField( 10 );
      c.add( text1 );

      // Construtor textfield com texto padrao
      text2 = new JTextField( "Entre com texto aqui" );
      c.add( text2 );

      // Construtor textfield com texto padrao e
      // 20 elementos visiveis e sem evento handler (tratador)
      text3 = new JTextField( "Campo de texto nao editavel", 20 );
      text3.setEditable( false );
      c.add( text3 );

      // Construtor passwordfield com texto padrao
      password = new JPasswordField( "Hidden text" );
      c.add( password );

      TextFieldHandler handler = new TextFieldHandler();
      text1.addActionListener( handler );
      text2.addActionListener( handler );
      text3.addActionListener( handler );
      password.addActionListener( handler );
      
      setSize( 325, 100 );
      show();
   }

   public static void main( String args[] ) { 
      DemoJtfJpf2 app = new DemoJtfJpf2();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );
   }

   // classe interna para eventos handling
   private class TextFieldHandler implements ActionListener {
      public void actionPerformed( ActionEvent e ) {
         String s = "";

         if ( e.getSource() == text1 )
            s = "text1: " + e.getActionCommand();
         else if ( e.getSource() == text2 )
            s = "text2: " + e.getActionCommand();
         else if ( e.getSource() == text3 )
            s = "text3: " + e.getActionCommand();
         else if ( e.getSource() == password ) {
            JPasswordField pwd =
               (JPasswordField) e.getSource();
            s = "password: " +
                new String( pwd.getPassword() );
         }

         JOptionPane.showMessageDialog( null, s );
      }
   }   
}

