import java.awt.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;

public class FrameArvoreSelecao extends JFrame {
   JTree arvore;
   JTextField selecionado;

   public FrameArvoreSelecao() {
      super("Demostracao de selecao em estruturas de Arvores");
      
      setTitle("Arvore");
      setBounds(100,100,300,300);
      Container c = getContentPane();

      DefaultMutableTreeNode raiz = new DefaultMutableTreeNode("Raiz");
      DefaultMutableTreeNode filho1 = new DefaultMutableTreeNode("Filho 1");
      raiz.add(filho1);
      DefaultMutableTreeNode filho2 = new DefaultMutableTreeNode("Filho 2");
      raiz.add(filho2);
      arvore = new JTree(raiz);

      JScrollPane panearvore = new JScrollPane(arvore);
      c.add(panearvore,BorderLayout.CENTER);

      selecionado = new JTextField();
      c.add(selecionado,BorderLayout.SOUTH);

      arvore.addTreeSelectionListener(new TreeSelectionListener()
      {
         public void valueChanged(TreeSelectionEvent event)
         {
            selecionado.setText(arvore.getLastSelectedPathComponent().toString());
         }
      } );
   }

   public static void main(String args[]) {
      FrameArvoreSelecao app = new FrameArvoreSelecao();
      app.setVisible(true);
      
     // Evento associado a fechar a janela
	 app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }
}
