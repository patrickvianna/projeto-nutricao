import javax.swing.*;
import java.awt.event.*;

public class Progresso extends JFrame {
   JButton botao; 	
   public Progresso() {
   	  super("Contador");
      
      botao = new JButton("Inicializa a contagem");
      botao.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            ProgressMonitor pm = new ProgressMonitor(Progresso.this,"Aguarde","",0,20);
            pm.setMillisToDecideToPopup(100);
            new Tarefa(pm).start();
         }
      });
      getContentPane().add(botao);
      pack();
      show();
   }

   public static void main(String args[]) {
      Progresso app = new Progresso();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );

   }
   
   class Tarefa extends Thread {
      ProgressMonitor pm;

      public Tarefa(ProgressMonitor pm) {
         this.pm = pm;
      }

      public void run() {
         for(int i=0;i<=20;i++) {
            try {
               sleep(200);
            }
            catch(InterruptedException ie) {
            }
            
            pm.setProgress(i);
         }
      }
   }
}

