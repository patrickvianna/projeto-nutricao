import javax.swing.*;
import java.awt.event.*;

public class ProgressoSemAdaptor extends JFrame {
   JButton botao; 	
   public ProgressoSemAdaptor() {
   	  super("Contador");
      
      botao = new JButton("Inicializa a contagem");
      botao.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            ProgressMonitor pm = new ProgressMonitor(ProgressoSemAdaptor.this,"Aguarde","",0,20);
            pm.setMillisToDecideToPopup(100);
            new Tarefa(pm).start();
         }
      });
      getContentPane().add(botao);      
      // show(); // a partir do jdk 1.5 este método foi depreciado. Usa-se apenas o setVisible(true);	
      pack();
      setVisible(true);
   }

   public static void main(String args[]) {
      ProgressoSemAdaptor app = new ProgressoSemAdaptor();

 	 // Evento associado a fechar a janela
	 app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }
   
   class Tarefa extends Thread {
      ProgressMonitor pm;

      public Tarefa(ProgressMonitor pm) {
         this.pm = pm;
      }

      public void run() {
         for(int i=0;i<=20;i++) {
            try {
               sleep(200);
            }
            catch(InterruptedException ie) {
            }
            
            pm.setProgress(i);
         }
      }
   }
}

