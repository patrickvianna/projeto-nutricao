import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class SliderDemo extends JFrame {
   private JSlider slider;
   private JLabel labelValor;

   public SliderDemo() {
      super( "Slider Demo" );

      // Constroi um JSlider na Horizontal, de 0 a 200, comecando com 10
      slider = new JSlider( SwingConstants.HORIZONTAL, 0, 200, 10 );
      labelValor = new JLabel("" + 10);
      
      slider.addChangeListener(
         new ChangeListener() {
            public void stateChanged( ChangeEvent e )
            {
               labelValor.setText("" + slider.getValue());
            }
         }
      );

      Container c = getContentPane();
      c.add( labelValor, BorderLayout.SOUTH );
      c.add( slider, BorderLayout.CENTER );

      pack();
      show();
   }

   public static void main( String args[] ) {
      SliderDemo app = new SliderDemo();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );
   }
}
