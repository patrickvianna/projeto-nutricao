import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TextArea2 extends JFrame {
   private JTextArea t1, t2;
   private JButton copia;
   
   public TextArea2() {
      super("Text Area");

      Container c = getContentPane();
      c.setLayout(new FlowLayout());

      t1 = new JTextArea(10,15);

      c.add(new JScrollPane(t1));

      copia = new JButton("Copia >>>");
      copia.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            t2.setText(t1.getSelectedText());
         }
      } );
      c.add(copia);

      t2 = new JTextArea(10,15);
      t2.setEditable( true );
      c.add(new JScrollPane(t2));

      pack();
   }

   public static void main(String args[]) {
      TextArea2 tac = new TextArea2();
      
      tac.addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
            System.exit(0);
         }
      } );
      tac.setVisible(true);
   }
}
