import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DemoEventosMouse1 extends JFrame{
	
	private JLabel barraStatus;
	
	public DemoEventosMouse1(String titulo){
		super(titulo);
		
		barraStatus = new JLabel();
		this.getContentPane().add(barraStatus,BorderLayout.SOUTH);
		
		this.addMouseListener(new MouseAdapter(){
			
			public void mouseClicked(MouseEvent e){
				barraStatus.setText("Mouse foi pressionado");
			}
			
			public void mouseEntered(MouseEvent e){
				barraStatus.setText("Mouse esta dentro da janela");
			}
			
			public void mouseExited(MouseEvent e){
				barraStatus.setText("Mouse esta fora da janela");
			}
			
		});
		
		setSize(275,100);
		setVisible(true);
	}
	
	public static void main(String args[]){
		DemoEventosMouse1 app = new DemoEventosMouse1("Usando Eventos Mouse");
		
		app.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
	}
}


