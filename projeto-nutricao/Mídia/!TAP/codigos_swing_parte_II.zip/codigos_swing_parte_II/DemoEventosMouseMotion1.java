import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DemoEventosMouseMotion1 extends JFrame {
   private JButton jButton1, jButton2;

   public DemoEventosMouseMotion1() {
      super( "Usando JButton" );

      this.getContentPane().setLayout( new FlowLayout() );

      // cria os botões
      jButton1 = new JButton( "jButton1" );
      this.add( jButton1 );

      Icon icone1 = new ImageIcon( "zcomputador.gif" );
      Icon icone2 = new ImageIcon( "zluz.gif" );
      jButton2 = new JButton( "jButton2", icone1 );
      jButton2.setRolloverIcon(icone2);
      this.add( jButton2 );

      ButtonHandler handler = new ButtonHandler();
      jButton1.addActionListener( handler );
      jButton2.addActionListener( handler );
	  jButton1.addMouseMotionListener( handler );
      jButton2.addMouseMotionListener( handler );

      setSize( 275, 100 );
      setVisible(true);
   }

   public static void main( String args[] ) { 
      DemoEventosMouseMotion1 app = new DemoEventosMouseMotion1();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );
   }

   // classe interna para evento de botoes (MouseMotionAdapter e ActionListener)
   private class ButtonHandler extends MouseMotionAdapter implements ActionListener{
      //ActionListener
      public void actionPerformed( ActionEvent e )
      {
         JOptionPane.showMessageDialog( null,
            "Voce pressionou: " + e.getActionCommand() );
      }
      //MouseMotionAdapter 
   	  public void mouseMoved(MouseEvent e)
   	  {
   	  	if ( e.getSource() == jButton1 )
   	  		System.out.println("Coordernadas do mouse sobre o jButton1: " + "X:"+e.getX() + " Y:"+e.getX());
   	    else if ( e.getSource() == jButton2 )
   	    	System.out.println("Coordernadas do mouse sobre o jButton2: " + "X:"+e.getX() + " Y:"+e.getX());
   	  }
   }
}

