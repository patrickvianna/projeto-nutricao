import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DemoJComboBox extends JFrame {
   private JComboBox comboImages;
   private JLabel label;
   private String nomeArquivo[] = { "zcomputador.gif", "zluz.gif" };
      
   private Icon icons[] =
      { new ImageIcon( nomeArquivo[ 0 ] ),
        new ImageIcon( nomeArquivo[ 1 ] )};

   public DemoJComboBox() {
      super( "Usando JComboBox" );
    
      this.getContentPane().setLayout( new FlowLayout() );      

      comboImages = new JComboBox( nomeArquivo );
      comboImages.setMaximumRowCount( 3 );

      comboImages.addItemListener(new ItemListener() {
            public void itemStateChanged( ItemEvent e )
            {
               label.setIcon(
                  icons[ comboImages.getSelectedIndex() ] );
            }
         }
      );

      this.add( comboImages );

      label = new JLabel( icons[ 0 ] );
      this.add( label );
      
      setSize( 350, 100 );
	  setVisible(true);
   }

   public static void main( String args[] ) { 
      DemoJComboBox app = new DemoJComboBox();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );
   }
}

