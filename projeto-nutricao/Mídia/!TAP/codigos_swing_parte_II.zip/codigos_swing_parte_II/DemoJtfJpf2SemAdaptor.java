import java.awt.*;
import java.awt.event.*; 
import javax.swing.*;

public class DemoJtfJpf2SemAdaptor extends JFrame {
   private JTextField text1, text2;
   private JPasswordField password;

   public DemoJtfJpf2SemAdaptor() {
      super( "Usando JTextField e JPasswordField" );

      this.getContentPane().setLayout( new FlowLayout() );

      // Construtor textfield com texto padrao
      text1 = new JTextField( "Entre com texto aqui" );
      this.add( text1 );

      // Construtor textfield com texto padrao e
      // 20 elementos visiveis e sem evento handler (tratador)
      text2 = new JTextField( "Campo de texto nao editavel", 20 );
      text2.setEditable( false );
      this.add( text2 );

      // Construtor passwordfield com texto padrao
      password = new JPasswordField( "Hidden text" );
      this.add( password );

      TextFieldHandler handler = new TextFieldHandler();
      text1.addActionListener( handler );
      text2.addActionListener( handler );
      password.addActionListener( handler );
      
      setSize( 325, 150 );
      setVisible(true);	

   }

   public static void main( String args[] ) { 
      DemoJtfJpf2SemAdaptor app = new DemoJtfJpf2SemAdaptor();

 	 // Evento associado a fechar a janela
	 app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }

   // classe interna para eventos handling (pressionar o Enter)
   private class TextFieldHandler implements ActionListener {
      public void actionPerformed( ActionEvent e ) {
         String s = "";

         if ( e.getSource() == text1 )
            s = "text1: " + e.getActionCommand();
         else if ( e.getSource() == text2 )
            s = "text2: " + e.getActionCommand();
         else if ( e.getSource() == password ) {
            JPasswordField pwd =
               (JPasswordField) e.getSource();
            s = "password: " +
                new String( pwd.getPassword() );
         }

         JOptionPane.showMessageDialog( null, s );
      }
   }   
}

