
import javax.swing.DefaultComboBoxModel;

public class ComboDinamico extends javax.swing.JFrame {

    public ComboDinamico() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jt_Categoria = new javax.swing.JTextField();
        jCB_Categoria = new javax.swing.JComboBox();
        jb_Inserir = new javax.swing.JButton();
        jL_Categoria = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Categoria");

        jCB_Categoria.setModel(new javax.swing.DefaultComboBoxModel(new String[] { " " }));
        jCB_Categoria.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCB_CategoriaItemStateChanged(evt);
            }
        });
        jCB_Categoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCB_CategoriaActionPerformed(evt);
            }
        });

        jb_Inserir.setText("Inserir");
        jb_Inserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jb_InserirActionPerformed(evt);
            }
        });

        jL_Categoria.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jL_Categoria.setBorder(javax.swing.BorderFactory.createTitledBorder("Elemento Selecionado"));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jL_Categoria, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jb_Inserir)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jCB_Categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jt_Categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jt_Categoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jb_Inserir)
                    .addComponent(jCB_Categoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jL_Categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jb_InserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jb_InserirActionPerformed
        DefaultComboBoxModel model = (DefaultComboBoxModel)jCB_Categoria.getModel();
        model.addElement(jt_Categoria.getText());
        jCB_Categoria.setModel(model);
    }//GEN-LAST:event_jb_InserirActionPerformed

    private void jCB_CategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCB_CategoriaActionPerformed
//         jL_Categoria.setText(jCB_Categoria.getSelectedItem().toString());
    }//GEN-LAST:event_jCB_CategoriaActionPerformed

    private void jCB_CategoriaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCB_CategoriaItemStateChanged
        // TODO add your handling code here:
         jL_Categoria.setText(jCB_Categoria.getSelectedItem().toString());
    }//GEN-LAST:event_jCB_CategoriaItemStateChanged
       
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new ComboDinamico().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox jCB_Categoria;
    private javax.swing.JLabel jL_Categoria;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton jb_Inserir;
    private javax.swing.JTextField jt_Categoria;
    // End of variables declaration//GEN-END:variables
}
