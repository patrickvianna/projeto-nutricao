import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

public class Modelo extends AbstractTableModel {

    List<Categoria> lista;

    private final int COLUNA_ID_CATEGORIA = 0;
    private final int COLUNA_NOME_CATEGORIA = 1;

    public Modelo(List<Categoria> list){
        this.lista = new ArrayList(list);
    }

    @Override
    public int getColumnCount() {
        // TODO Auto-generated method stub
        return 2;
    }

    @Override
    public int getRowCount() {
        // TODO Auto-generated method stub
        return this.lista.size();
    }

    @Override
    public Object getValueAt(int row, int column) {
        Categoria obj = this.lista.get(row);

        if(this.COLUNA_ID_CATEGORIA == column){
            return obj.getId();
        }
        if(this.COLUNA_NOME_CATEGORIA == column){
            return obj.getNome();
        }
        return null;
    }

    @Override
    public String getColumnName(int column){
        if(column == this.COLUNA_ID_CATEGORIA){
            return "ID";
        }
        if(column == this.COLUNA_NOME_CATEGORIA){
           return "Nome";
        }
        return null;
    }

    public void addLista(List<Categoria> list){
       this.lista = list;
       fireTableDataChanged();
    }

}