import java.awt.GridLayout;
import java.awt.event.*;
import javax.swing.*;

public class InfoLookAndFeel extends JFrame {
    private JLabel titleLabel = new JLabel("Titulo: ", SwingConstants.RIGHT);
    private JTextField title;

    public InfoLookAndFeel() {
        super("Site de Informacao");
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLookAndFeel();
        
        // Nome do Site
        String response1 = JOptionPane.showInputDialog(null, "Entre com o titulo do Site:");
        title = new JTextField(response1, 20);

        JPanel pane = new JPanel();
        pane.add(titleLabel);
        pane.add(title);
        this.setContentPane(pane);

        pack();

        setVisible(true);
    }

    private void setLookAndFeel() {
        try {
            UIManager.setLookAndFeel(
//                UIManager.getSystemLookAndFeelClassName());
//                UIManager.getCrossPlatformLookAndFeelClassName());
//				  "com.sun.java.swing.plaf.windows.WindowsLookAndFeel"); 
//			 	  "com.sun.java.swing.plaf.motif.MotifLookAndFeel"); 
//				  "javax.swing.plaf.metal.MetalLookAndFeel");
				  "com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel");					
//				  "com.sun.java.swing.plaf.gtk.GTKLookAndFeel");

            SwingUtilities.updateComponentTreeUI(this);
        } 
        catch (Exception e) {
            System.err.println("O sistema nao pode usar o Look and Feel desejado: " + e);
        }
    }

    public static void main(String[] arguments) {
         InfoLookAndFeel frame = new InfoLookAndFeel();
        
		 // Evento associado a fechar a janela
		 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        
		 
    }
}
