import javax.swing.JInternalFrame;
import javax.swing.JDesktopPane;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JMenuBar;
import javax.swing.JFrame;
import java.awt.event.*;
import java.awt.*;

public class InternalFrameDemo extends JFrame {
   JDesktopPane desktop;

   public InternalFrameDemo() {
      super("InternalFrameDemo");

      // Dimensiona a janela principal
      int inset = 50;
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      setBounds(inset, inset, screenSize.width - inset*2, screenSize.height-inset*2);

      addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
            System.exit(0);
         }
      });

      desktop = new JDesktopPane();
      // Cria uma janela interna
      createFrame();
      this.setContentPane(desktop);
      setJMenuBar(createMenuBar());

      desktop.putClientProperty("JDesktopPane.dragMode", "outline");
   }

   protected JMenuBar createMenuBar()  {
      JMenuBar menuBar = new JMenuBar();

      JMenu menu = new JMenu("Document");
      menu.setMnemonic(KeyEvent.VK_D);
      JMenuItem menuItem = new JMenuItem("New");
      menuItem.setMnemonic(KeyEvent.VK_N);
      menuItem.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            createFrame();
         }
      });
      menu.add(menuItem);
      menuBar.add(menu);

      return menuBar;
   }

   protected void createFrame() {
      MyInternalFrame frame = new MyInternalFrame();
      frame.setVisible(true);
      desktop.add(frame);
      try {
         frame.setSelected(true);
      }
      catch (java.beans.PropertyVetoException e) {
      }
   }

   public static void main(String[] args)  {
      InternalFrameDemo frame = new InternalFrameDemo();
      frame.setVisible(true);
   }
}


class MyInternalFrame extends JInternalFrame {
   static int openFrameCount = 0;
   static final int xOffset = 30, yOffset = 30;

   public MyInternalFrame() {
      super("Documento #" + (++openFrameCount),
            true, //resize
            true, //fechar
            true, //maximizar
            true);//minimizar

      setSize(300,300);

      setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
   }
}



