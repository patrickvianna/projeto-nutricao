import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class ModificaTabela extends JFrame {
   MyTableModel myModel;
   JTable table;
   int selectedindex;

   public ModificaTabela() {
      super("Tabela");

      myModel = new MyTableModel();
      table = new JTable(myModel);
      table.setPreferredScrollableViewportSize(new Dimension(500, 170));

      JScrollPane scrollPane = new JScrollPane(table);
      getContentPane().add(scrollPane, BorderLayout.CENTER);

      JButton insert = new JButton("Insere linha");
      JButton remove = new JButton("Remove linha");
      JPanel panelbuttons = new JPanel();
      panelbuttons.add(insert);
      panelbuttons.add(remove);
      getContentPane().add(panelbuttons, BorderLayout.SOUTH);

      insert.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            myModel.addRow();
               
         }
      } );

      remove.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            try
            {
               myModel.removeRow(selectedindex);
            }
            catch(NoSuchRowException nsre)
            {
            }
         }
      } );

      addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
            System.exit(0);
         }
      });

      ListSelectionModel rowSM = table.getSelectionModel();
      rowSM.addListSelectionListener(new ListSelectionListener()
      {
         public void valueChanged(ListSelectionEvent e)
         {
            if (e.getValueIsAdjusting()) return;
                
            ListSelectionModel lsm = (ListSelectionModel)e.getSource();
            if (lsm.isSelectionEmpty())
               selectedindex = -1;
            else
               selectedindex = lsm.getMinSelectionIndex();
         }
      });
   }

   class MyTableModel extends AbstractTableModel {
      Vector data;
      Vector columnNames;

      public MyTableModel() {
         data = new Vector();
         Vector newrow = new Vector();
         newrow.add("");
         newrow.add("");
         newrow.add(new Integer(0));
         newrow.add(new Boolean(false));
         data.add(newrow);
         columnNames = new Vector();
         columnNames.add("Modulo");
         columnNames.add("Instrutor");
         columnNames.add("# horas");
         columnNames.add("Finalizado");
      }

      public void removeRow(int index) throws NoSuchRowException {
         try
         {
            data.remove(index);
            fireTableStructureChanged();
         }
         catch(ArrayIndexOutOfBoundsException e)
         {
            throw new NoSuchRowException();
         }
      }

      public void addRow() {
         Vector newrow = new Vector();
         newrow.add("");
         newrow.add("");
         newrow.add(new Integer(0));
         newrow.add(new Boolean(false));
         data.add(newrow);
         fireTableStructureChanged();
      }

      public int getColumnCount() {
         return columnNames.size();
      }
        
      public int getRowCount() {
         if(data!=null)
            return data.size();
         else return 0;
      }

      public String getColumnName(int col) {
         return (String)columnNames.get(col);
      }

      public Object getValueAt(int row, int col) {
         return ((Vector)(data.get(row))).get(col);
      }

      public Class getColumnClass(int c) {
         return getValueAt(0, c).getClass();
      }

      public boolean isCellEditable(int row, int col) {
         return true;
      }

      public void setValueAt(Object value, int row, int col) {
         ((Vector)(data.get(row))).set(col,value);
         fireTableCellUpdated(row, col);
         System.out.println(data);
      }
   }

   public static void main(String[] args) {
      ModificaTabela frame = new ModificaTabela();
      frame.pack();
      frame.setVisible(true);
   }

   class NoSuchRowException extends Exception {
      public String getMessage() { return "Problemas ao remover a linha"; }
   }
}


