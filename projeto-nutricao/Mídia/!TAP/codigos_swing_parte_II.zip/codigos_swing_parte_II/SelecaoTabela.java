import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.*;

public class SelecaoTabela extends JFrame {
   
   private boolean ALLOW_COLUMN_SELECTION = true;
   private boolean ALLOW_ROW_SELECTION = true;
//   private boolean ALLOW_COLUMN_SELECTION = false;
//   private boolean ALLOW_ROW_SELECTION = false;

   public SelecaoTabela() {
      super("Tabela selecionavel");

      Object[][] data = {
            {"Modelagem OO", "Prado", new Integer(8), new Boolean(true)},
            {"Programacao Java/OO", "Prado", new Integer(4), new Boolean(true)},
            {"Modulo JDK1", "Daniel", new Integer(4), new Boolean(true)},
            {"Modulo JDK2", "Raphael", new Integer(4), new Boolean(true)},
            {"Modulo JDK3", "Daniel", new Integer(4), new Boolean(false)},
            {"Modulo Visual1", "Raphael", new Integer(4), new Boolean(true)},
            {"Modulo Visual2", "Daniel", new Integer(4), new Boolean(false)}
      };

      String[] columnNames = {"Modulo","Instrutor","# Horas","Finalizado"};

      final JTable table = new JTable(data, columnNames);
      table.setPreferredScrollableViewportSize(new Dimension(500, 70));
      table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

      if (ALLOW_ROW_SELECTION) {
         table.setRowSelectionAllowed(true);
         
         ListSelectionModel rowSM = table.getSelectionModel();
         rowSM.addListSelectionListener(new ListSelectionListener()
         {
            public void valueChanged(ListSelectionEvent e)
            {
               if (e.getValueIsAdjusting()) return;
                   
               ListSelectionModel lsm = (ListSelectionModel)e.getSource();
               if (lsm.isSelectionEmpty())
               {
                  System.out.println("Nenhuma linha selecionada");
               }
               else
               {
                  int selectedRow = lsm.getMinSelectionIndex();
                  System.out.println("Linha " + selectedRow + " foi selecionada");
               }
            }
         });
         }
         else
         {
            table.setRowSelectionAllowed(false);
         }

         if (ALLOW_COLUMN_SELECTION) {
            if (ALLOW_ROW_SELECTION)
            {
                table.setCellSelectionEnabled(true);
            } 
            table.setColumnSelectionAllowed(true);
            ListSelectionModel colSM = table.getColumnModel().getSelectionModel();
            colSM.addListSelectionListener(new ListSelectionListener()
            {
               public void valueChanged(ListSelectionEvent e)
               {
                  if (e.getValueIsAdjusting()) return;

               ListSelectionModel lsm = (ListSelectionModel)e.getSource();
               if (lsm.isSelectionEmpty())
               {
                  System.out.println("Nenhuma columa are selecionada.");
               }
               else
               {
                  int selectedCol = lsm.getMinSelectionIndex();
                  System.out.println("Coluna " + selectedCol + " foi selecionada");
               }
            }
        });
      }

      JScrollPane scrollPane = new JScrollPane(table);
      getContentPane().add(scrollPane, BorderLayout.CENTER);
      addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
            System.exit(0);
         }
      });
   }

   public static void main(String[] args) {
      SelecaoTabela frame = new SelecaoTabela();
      frame.pack();
      frame.setVisible(true);
   }
}


