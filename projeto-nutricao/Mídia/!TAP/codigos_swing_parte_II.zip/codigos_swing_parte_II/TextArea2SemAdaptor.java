import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TextArea2SemAdaptor extends JFrame {
   private JTextArea t1, t2;
   private JButton copia;
   
   public TextArea2SemAdaptor() {
      super("Text Area");

      this.getContentPane().setLayout(new FlowLayout());

      t1 = new JTextArea(10,15);
	  this.add(new JScrollPane(t1));

      copia = new JButton("Copia >>>");
      this.add(copia);
      copia.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            t2.setText(t1.getText());
            //t2.setText(t1.getSelectedText());
         }
      } );
      

      t2 = new JTextArea(10,15);
      this.add(new JScrollPane(t2));

      pack();      
   }

   public static void main(String args[]) {
      TextArea2SemAdaptor tac = new TextArea2SemAdaptor();
      
	 tac.setVisible(true);

 	 // Evento associado a fechar a janela
	 tac.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     
   }
}

