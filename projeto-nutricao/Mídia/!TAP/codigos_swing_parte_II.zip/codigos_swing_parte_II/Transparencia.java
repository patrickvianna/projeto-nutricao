/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.sun.awt.AWTUtilities;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;

public class Transparencia {

public static void main(String [] args)     {

final JFrame  window = new JFrame("Minha janela");

                try {
                    //Adicionando o ComponentListener responsável pelo componentResized
                    window.addComponentListener(new ComponentAdapter(){
                            //implementando o método componentResized
                            public void componentResized(ComponentEvent e) {
                                    int[] x = {0,400,800}; //Pontos X do polígono
                                    int[] y = {600,0,600}; //Pontos Y do polígono

                                    //Criaremos um triângulo de 800 x 600
                                    Shape shape = new Polygon(x, y, 3);

                                    AWTUtilities.setWindowShape(window, shape);

                                    //com transparência de 70%
                                    AWTUtilities.setWindowOpacity(window, 0.7f);
                            }
                    });
                } catch (SecurityException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                } catch (IllegalArgumentException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }

            // Descomente essa linha e veja o que acontece...
            //window.setUndecorated(true); //removendo barra de título

            window.setSize(800,600);
            window.setVisible(true);

              window.addWindowListener(
                 new WindowAdapter() {
                    public void windowClosing( WindowEvent e )
                    {
                       System.exit( 0 );
                    }
                 }
                );
    }
}
